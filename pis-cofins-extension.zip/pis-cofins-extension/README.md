# Calculadora PIS / COFINS — Extensão para Chrome

Extensão que calcula PIS e COFINS nos regimes de **Lucro Presumido** e **Lucro Real** diretamente no navegador, sem sair da página.

---

## Como instalar localmente (para testes)

1. Abra o Chrome e acesse `chrome://extensions`
2. Ative o **Modo do desenvolvedor** (canto superior direito)
3. Clique em **"Carregar sem compactação"**
4. Selecione a pasta `pis-cofins-extension`
5. O ícone aparecerá na barra de ferramentas do Chrome

---

## Como publicar na Chrome Web Store

### 1. Criar o arquivo ZIP
Compacte **o conteúdo** da pasta (não a pasta em si):
- `manifest.json`
- `popup.html`
- `popup.css`
- `popup.js`
- `icons/` (pasta com os 4 PNGs)

### 2. Acessar o Developer Dashboard
- Acesse: https://chrome.google.com/webstore/devconsole
- Faça login com sua conta Google
- Pague a taxa única de desenvolvedor: **US$ 5,00** (cobrada uma única vez)

### 3. Criar novo item
- Clique em **"Novo item"**
- Faça upload do arquivo `.zip`

### 4. Preencher os metadados obrigatórios

| Campo | Sugestão |
|-------|----------|
| **Nome** | Calculadora PIS / COFINS |
| **Descrição curta** | Calcule PIS e COFINS nos regimes de Lucro Presumido e Lucro Real de forma rápida, sem sair do navegador. |
| **Categoria** | Ferramentas de produtividade |
| **Idioma** | Português (Brasil) |
| **Visibilidade** | Público |

### 5. Screenshots obrigatórias
A Google exige ao menos **1 screenshot** (1280×800 ou 640×400 px).
Tire prints do popup em funcionamento.

### 6. Ícone para a loja
Use o arquivo `icons/icon128.png` como ícone principal da listagem.

### 7. Enviar para revisão
- Clique em **"Enviar para revisão"**
- O processo de aprovação leva entre **1 a 3 dias úteis**

---

## Estrutura de arquivos

```
pis-cofins-extension/
├── manifest.json       ← configuração da extensão (Manifest V3)
├── popup.html          ← interface principal
├── popup.css           ← estilos
├── popup.js            ← lógica e cálculos
└── icons/
    ├── icon16.png
    ├── icon32.png
    ├── icon48.png
    └── icon128.png
```

---

## Alíquotas utilizadas

| Regime | PIS | COFINS | Total |
|--------|-----|--------|-------|
| Lucro Presumido (cumulativo) | 0,65% | 3,00% | 3,65% |
| Lucro Real (não cumulativo)  | 1,65% | 7,60% | 9,25% |

> Alíquotas gerais conforme legislação vigente. Setores específicos podem ter alíquotas diferenciadas.

---

## Permissões utilizadas

- `storage` — para salvar o histórico de cálculos localmente no navegador
